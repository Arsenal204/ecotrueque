<footer class="bg-[#B4007C] text-white mt-10">
    <div class="max-w-7xl mx-auto py-6 px-4 flex flex-col sm:flex-row justify-between items-center">
        <p class="text-sm">&copy; {{ date('Y') }} EcoTrueque. Todos los derechos reservados.</p>

        <div class="flex space-x-4 mt-2 sm:mt-0">
            <a href="#" class="text-[#FFEA27] hover:underline text-sm">Aviso legal-</a>
            <a href="#" class="text-[#FFEA27] hover:underline text-sm">-Política de privacidad-</a>
            <a href="#" class="text-[#FFEA27] hover:underline text-sm">-Contacto-</a>
        </div>
    </div>
</footer>
