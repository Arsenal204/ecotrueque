<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
            {{ __('Editar objeto') }}
        </h2>
    </x-slot>

    <div class="py-6">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8 bg-white dark:bg-gray-800 p-6 shadow rounded">
            <form method="POST" action="{{ route('objetos.update', $objeto) }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Título -->
                <div class="mb-4">
                    <label for="titulo"
                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Título</label>
                    <input type="text" name="titulo" id="titulo" value="{{ old('titulo', $objeto->titulo) }}"
                        required
                        class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                </div>

                <!-- Descripción -->
                <div class="mb-4">
                    <label for="descripcion"
                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Descripción</label>
                    <textarea name="descripcion" id="descripcion" rows="3"
                        class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">{{ old('descripcion', $objeto->descripcion) }}</textarea>
                </div>

                <!-- Estado -->
                <div class="mb-4">
                    <label for="estado"
                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Estado</label>
                    <input type="text" name="estado" id="estado" value="{{ old('estado', $objeto->estado) }}"
                        required
                        class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                </div>

                <!-- Tipo de oferta -->
                <div class="mb-4">
                    <label for="tipo_oferta" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipo de
                        oferta</label>
                    <select name="tipo_oferta" id="tipo_oferta"
                        class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                        <option value="donación" {{ $objeto->tipo_oferta == 'donación' ? 'selected' : '' }}>Donación
                        </option>
                        <option value="trueque" {{ $objeto->tipo_oferta == 'trueque' ? 'selected' : '' }}>Trueque
                        </option>
                    </select>
                </div>

                <!-- Categoría -->
                <div class="mb-4">
                    <label for="categoria"
                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Categoría</label>
                    <select name="categoria" id="categoria"
                        class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                        @foreach ($categorias as $categoria)
                            <option value="{{ $categoria->id }}"
                                {{ $objeto->categoria == $categoria->id ? 'selected' : '' }}>
                                {{ $categoria->nombre_categoria }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- Galería existente -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Imágenes
                        actuales</label>
                    <div class="grid grid-cols-2 gap-4">
                        @foreach ($objeto->imagenes as $imagen)
                            <div class="relative">
                                <img src="{{ asset('storage/' . $imagen->ruta_imagen) }}"
                                    class="w-full h-32 object-cover rounded shadow" alt="Imagen">
                                <form action="{{ route('galerias.destroy', $imagen) }}" method="POST"
                                    class="absolute top-1 right-1"
                                    onsubmit="return confirm('¿Seguro que quieres eliminar esta imagen?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                        class="bg-red-600 text-white text-xs px-2 py-1 rounded">X</button>
                                </form>

                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- Subida de nuevas imágenes -->
                <div class="mb-4">
                    <label for="imagenes" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Añadir
                        nuevas imágenes</label>
                    <input type="file" name="imagenes[]" id="imagenes" multiple
                        class="mt-1 block w-full text-sm text-gray-900 bg-gray-50 dark:bg-gray-700 dark:text-white border border-gray-300 rounded">
                </div>

                <!-- Botón guardar -->
                <div class="text-right">
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Guardar
                        cambios</button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
