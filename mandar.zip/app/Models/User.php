<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'tipo_usuario',
        'direccion',
        'ciudad',
        'telefono',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
    // app/Models/User.php

    public function objetos()
    {
        return $this->hasMany(Objeto::class, 'usuario');
    }

    public function direcciones()
    {
        return $this->hasMany(Direccion::class, 'usuario');
    }

    public function notificaciones()
    {
        return $this->hasMany(Notificacion::class, 'usuario_receptor');
    }

    public function reclamacionesEmitidas()
    {
        return $this->hasMany(Reclamacion::class, 'usuario_emisor');
    }

    public function reclamacionesRecibidas()
    {
        return $this->hasMany(Reclamacion::class, 'usuario_reclamado');
    }
    public function valoraciones()
    {
        return $this->hasMany(Valoracion::class, 'id_usuario_valorado');
    }
}
