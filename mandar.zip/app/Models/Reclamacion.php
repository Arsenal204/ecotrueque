<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Reclamacion extends Model
{
    use HasFactory;

    protected $table = 'reclamaciones';

    protected $fillable = ['motivo', 'descripcion', 'fecha_reclamacion', 'estado_reclamacion', 'usuario_emisor', 'usuario_reclamado', 'intercambio', 'ruta_imagen'];


    public function emisor()
    {
        return $this->belongsTo(User::class, 'id_usuario_emisor');
    }

    public function reclamado()
    {
        return $this->belongsTo(User::class, 'id_usuario_reclamado');
    }

    public function intercambio()
    {
        return $this->belongsTo(Intercambio::class, 'id_intercambio');
    }
}
